class Controller:
    def __init__(self):
        self.cars = []
        self.drivers = []
        self.races = []

    def create_car(self, car_type, model, speed_limit):
        # if Validator.same_model_like_object_model(model, self.cars) is not None:
        #     raise Exception(f"Car {model} is already created!")
        # car = CarFactory.car_creation(car_type, speed_limit)
        # self.cars.append(car)
        # return f"{car_type} {model} is created."
        pass

    def create_driver(self, driver_name: str):
        # if Validator.same_name_like_object_name(driver_name, self.drivers) is not None:
        #     raise Exception(f"Driver {driver_name} is already created!")
        # driver = Driver(driver_name)
        # self.drivers.append(driver)
        # return f"Driver {driver_name} is created."
        pass

    def create_race(self, race_name):
        # if any(Validator.same_name_like_object_name(race_name, self.races)):
        #     raise Exception(f"Race {race_name} is already created!")
        # race = Race(race_name)
        # self.races.append(race)
        # return f"Race {race_name} is created."
        pass

    def add_car_to_driver(self, driver_name: str, car_type: str):
        # driver = Validator.same_name_like_object_name(driver_name, self.drivers)
        # reversed_cars = reversed(self.cars)
        # car = Validator.same_model_like_object_model(car_type, reversed_cars)
        # if any(driver):
        #     raise Exception(f"Driver {driver_name} could not be found!")
        # if any(car):
        #     raise Exception(f"Car {car_type} could not be found!")
        pass

    def add_driver_to_race(self, race_name: str, driver_name: str):
        pass

    def start_race(self, race_name):
        pass

#
# c = Controller()
# c.create_car("MuscleCar", "Ford", 400)
# a = 1
