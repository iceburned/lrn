# from project.car.muscle_car import MuscleCar
# from project.car.sports_car import SportsCar
#
#
# class CarFactory:
#     @staticmethod
#     def car_creation(car_type, speed_limit):
#         car_types = {
#             "MuscleCar": MuscleCar,
#             "SportsCar": SportsCar
#         }
#         return car_types[car_type](speed_limit)
