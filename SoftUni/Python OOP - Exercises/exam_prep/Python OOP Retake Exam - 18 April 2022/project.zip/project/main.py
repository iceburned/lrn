from project.movie_app import MovieApp
from project.movie_specification.action import Action
from project.movie_specification.fantasy import Fantasy
from project.movie_specification.thriller import Thriller
from project.user import User

u = User("Ivan", 20)
aasdd = 1

f = Fantasy("Forever", 2000, u)
a = Action("Die", 2001, u)
t = Thriller("Psiho", 1960, u)
m = MovieApp()
print(m.register_user("Teo", 33))
print(m.register_user("Ivan", 20))
print(m.upload_movie("Ivan", f))
print(m.edit_movie("Ivan", f, **{"year": 2001, "title": "Die easy"}))
print(m.delete_movie("Ivan", f))
zzz = 1