from project.pokemon import Pokemon


class Trainer:
    def __init__(self, name: str):
        self.name = name
        self.pokemons = []

    def add_pokemon(self, pokemon: Pokemon):
        if any([_.name == pokemon.name for _ in self.pokemons]):
            return "This pokemon is already caught"
        else:
            self.pokemons.append(pokemon)
            return f"Caught {pokemon.pokemon_details()}"

    def release_pokemon(self, pokemon_name: str):
        for obj in self.pokemons:
            if obj.name == pokemon_name:
                self.pokemons.remove(obj)
                return f"You have released {pokemon_name}"
        else:
            return "Pokemon is not caught"

    def trainer_data(self):
        trainer_info = [
            f'Pokemon Trainer {self.name}',
            f'Pokemon count {len(self.pokemons)}',
        ]
        pokemon_info = [f'- {p.pokemon_details()}' for p in self.pokemons]
        return "\n".join(trainer_info + pokemon_info) + '\n'


first_pokemon = Pokemon("Pikachu", 90)
print(first_pokemon.pokemon_details())
trainer = Trainer("Ash")
print(trainer.add_pokemon(first_pokemon))
second_pokemon = Pokemon("Charizard", 110)
print(trainer.add_pokemon(second_pokemon))
print(trainer.add_pokemon(second_pokemon))
print(trainer.release_pokemon("Pikachu"))
print(trainer.release_pokemon("Pikachu"))
print(trainer.trainer_data())
