from project.task import Task


class Section:
    def __init__(self, name):
        self.name = name
        self.tasks = []

    def add_task(self, new_task: Task):
        if new_task not in self.tasks:
            self.tasks.append(new_task)
            return f"Task {new_task.details()} is added to the section"
        return f"Task is already in the section {self.name}"

    def complete_task(self, task_name: str):
        for obj in self.tasks:
            if obj.name == task_name:
                obj.completed = True
                return f"Completed task {task_name}"
        return f"Could not find task with the name {task_name}"

    def clean_section(self):
        idx = 0
        for obj in self.tasks:
            if obj.completed:
                self.tasks.remove(obj)
                idx += 1
        return f"Cleared {idx} tasks."

    def view_section(self):
        anwr = f"Section {self.name}"
        asdd = [_.details() for _ in self.tasks]
        return f"{anwr}:\n" + '\n'.join(asdd)










